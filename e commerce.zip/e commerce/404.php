<?php get_template_part( 'si-post' ); ?>

<?php //wp_redirect( 'cart.php' ); exit; ?>


	<main>
		<div class="container mt-3">

				<h1 class="alert alert-danger">Page Not Found</h1>

		</div>
		<div id="side">
			<?php if ( is_active_sidebar( 'recent-posts' ) ): ?>

			    <?php dynamic_sidebar( 'recent-posts' ); ?>
			    
			<?php endif; ?>
		</div>
	</main>

<?php get_sidebar();?>
<?php get_footer();?>