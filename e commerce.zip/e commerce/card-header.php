<!DOCTYPE html>
<html>
<head>
	<meta name="viewport" content="width=device-width, initial-scale=1" />
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" 
	  integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.3.0/font/bootstrap-icons.css">
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Abel&display=swap" rel="stylesheet">

	<link id="link-css" rel="stylesheet" href="http://localhost/wordpress/wp-content/themes/e-commerce/assets/css/mobile/mobMain.css">

	<!--
	<link rel="stylesheet" media="screen and (max-width: 500px)" href="<?php //echo get_template_directory_uri();?>/assets/css/mobile/mobMain.css">
	<link rel="stylesheet" media="screen and (min-width: 500px)" href="<?php //echo get_template_directory_uri();?>/assets/css/web/webMain.css">
-->
	<title>title</title>

</head>
<style>
	
@media screen and (max-width: 240px) {
  /*--------------------------------------index.php style-------------------------------*/
  body{
    font-size: .75rem;
    font-family: 'Abel', sans-serif;
    width: 100% !important;
    overflow-x: hidden !important;
  }
  i{
    font-size: .75rem;
  }
  div#social-icons{
    display: block;
    background-color: #ff8d00e0;
  }
  #navbarSupportedContent div ul{
    display: inline-block;
  }
  #navbarSupportedContent div ul li{
    display: block;
  }
  div#social-icons ul{
    display: none;
  }
  #slide{
    padding-top: 0;
  }
  #slide .container{
    height: 50vh !important;
    padding-top: 0;
  }
  #cats ul{
    display: inline-block;
  }

  main .container{
    height: 1800px;background-color: #e3e3e3;
  }
  .card{
    margin-bottom: 5px;
  }
  #card-post img{
    width: 100%;
    height: 150px;
  }
  #card-post .card-footer a.btn{
    width: 45%;
    float: left;
    font-size: .85rem;
    padding: 3px 0;
    margin-right: 2.5%;margin-bottom: 2px;
  }
  #card-post .card-footer span{
    width: 95%;
    float: left;
    font-size: .85rem;
    margin-right: 5%;
  }
  #icons ul li{
    float: left;
  }
  #topButton{
    float: right;
  }

  /*--------------------------------------cart.php style-------------------------------*/
  main#main-cart{
    padding-top: 10rem;
  }
  div#cart-categories ul{
    display: none !important;
  }
  main#main-cart a,span{
    margin: 5px 2px;
    text-align: center;
  }
  main#main-cart div.container div.card{
    width: 100%;padding: 0;background-color: #e3e3e3;
  }
  main#main-cart div.container div.card div.card-footer a.btn{
    margin: 0;
  }
  .card a.btn,span{
    padding: .1rem !important;
  }
  footer{
    height: 400px;
  }
}

</style>
<body>

	<!-----------------------------------------header item--------------------------------->
	<header>
		<nav class="navbar navbar-expand-lg navbar-light row" style="margin-top: 0;padding-top: 0;">
			<div class="container-fluid col-md-4 col-sm-4 col-xl-4 float-start" style="background-color: #ff8d00e0;">
			    <a class="navbar-brand text-light" href="http://localhost/wordpress/index.php">E Commerce</a>
			    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
			    	<span class="navbar-toggler-icon"></span>
			    </button>
          <div class="collapse navbar-collapse" id="navbarSupportedContent">
  
            <div id="cats">
              <ul class="w-100">
                  <li class="nav-item"><a class="nav-link text-light fs-5" href="#">Apple</a></li>
                  <li class="nav-item"><a class="nav-link text-light fs-5" href="#">Samsung</a></li>
                  <li class="nav-item"><a class="nav-link text-light fs-5" href="#">Sony</a></li>
              </ul>
            </div>
          </div>
			</div>
			<!-----------------------------------------social media items--------------------------------->
			
			<div class="col-md-4 col-sm-4 col-xl-4" id="cart-categories">
				<ul class="navbar-nav me-auto mb-2 mb-lg-0">
					<li class="nav-item">
				  		<a class="nav-link" aria-current="page" href="https://www.facebook.com"><i class="bi bi-facebook"></i></a>
					</li>
					<li class="nav-item">
				  		<a class="nav-link" id="drop" aria-current="page" href="https://www.instagram.com"><i class="bi bi-instagram"></i></a>
					</li>
					<li class="nav-item">
				  		<a class="nav-link" id="drop" aria-current="page" href="https://www.youtube.com"><i class="bi bi-youtube"></i></a>
					</li>
					<li class="nav-item">
				  		<a class="nav-link" id="drop" aria-current="page" href="https://www.tiktok.com"><i class="bi bi-tiktok"></i></a>
					</li>
					<li class="nav-item">
				  		<a class="nav-link" id="drop" aria-current="page" href="cart.php?action=all"><i class="bi bi-cart"></i></a>
					</li>
				</ul>
			</div>
		
		</nav>
	</header>

