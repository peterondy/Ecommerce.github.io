		<footer class="mt-2 bg-dark text-light">
			<div class="container">
				<div class="row">

					<!-----------------------------------------footer pages--------------------------------->

					<?php get_template_part( 'templates/footer/pages-footer' ); ?>

					<!-----------------------------------------footer categories--------------------------------->

					<?php get_template_part( 'templates/footer/categories-footer' ); ?>
					
					<!-----------------------------------------footer icons--------------------------------->

					<?php get_template_part( 'templates/footer/icons-footer' ); ?>

					
				</div>
			</div>
		</footer>

	<script type="text/javascript" src="<?php echo get_template_directory_uri();?>/assets/js/script.js"></script>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
	<script type="text/javascript">
		let btnTop = getElementById("topButton");
		function clickBtn(){
			document.documentElement.scrollTop = 0;
		}

		let width = screen.width;
		if(width < 1200){
			document.getElementById("link-css").href = "<?php //echo get_template_directory_uri();?>/assets/css/web/webMain.css";
		}else{
			document.getElementById("link-css").href = "<?php //echo get_template_directory_uri();?>/assets/css/mobile/mobMain.css";
		}
		console.log(document.getElementById("link-css").href);
	</script>
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" 
		integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
		<?php //wp_footer(); ?>
	</body>
</html>