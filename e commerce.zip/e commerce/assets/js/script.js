/*$(document).ready(function() {
    $width = $(window).width();
    console.log($width);
    //if( $width < )
    //$("#link-css").attr("href", "bar.css");
});*/