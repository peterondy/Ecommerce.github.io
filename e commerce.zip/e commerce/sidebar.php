<aside class="row mt-3 w-100 mb-4">



	<!-----------------------------------------footer pages--------------------------------->

	<?php get_template_part( 'templates/sidebar/email-subscribe-sidebar' ); ?>

</aside>