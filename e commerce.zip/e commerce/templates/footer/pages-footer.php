<div id="pages" class="pt-2 col-md-4">
	<ul>
		<h6>Pages</h6>
	    <li class="nav-item d-block"><a class="nav-link" href="#">About</a></li>
	    <li class="nav-item d-block"><a class="nav-link" href="#">Privacy Policy</a></li>
	    <li class="nav-item d-block"><a class="nav-link" href="#">Contact</a></li>
    </ul>
</div>