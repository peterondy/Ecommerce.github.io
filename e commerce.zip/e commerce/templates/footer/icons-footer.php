<div id="icons" class="pt-2 col-md-4">
	<ul>
		<h6>Pages</h6>
	    <li class="nav-item" style="display: inline-block;"><a class="nav-link" href="#"><i class="bi bi-facebook"></i></a></li>
	    <li class="nav-item" style="display: inline-block;"><a class="nav-link" href="#"><i class="bi bi-github"></i></a></li>
	    <li class="nav-item" style="display: inline-block;"><a class="nav-link" href="#"><i class="bi bi-youtube"></i></a></li>
	    <li class="nav-item" style="display: inline-block;"><button class="nav-link btn btn-dark text-light"><i class="bi bi-arrow-up-circle" id="topButton" onclick="clickBtn()"></i></button></li>
    </ul>
</div>