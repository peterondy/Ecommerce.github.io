<div id="footerCats" class="pt-2 col-md-4">
	<ul>
		<h6>Categories</h6>
	    <li class="nav-item d-block"><a class="nav-link" href="#">Apple</a></li>
	    <li class="nav-item d-block"><a class="nav-link" href="#">Samsung</a></li>
	    <li class="nav-item d-block"><a class="nav-link" href="#">Sony</a></li>
	</ul>
</div>