<div class="col-md-6">
	<h1 class="text-center text-success" style="margin-top: 10%;">Subscribe On Website News</h1>
</div>
<div class="col-md-6 fs-4">
	<div id="side">
	   <input type="email" class="w-100" name="email" placeholder="Enter Your Email">
	</div>
</div>