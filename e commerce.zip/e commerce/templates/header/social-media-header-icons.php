<div id="social-icons" class="col-md-4 col-sm-4 col-xl-4">
	<ul class="navbar-nav me-auto mb-2 mb-lg-0">
		<li class="nav-item">
	  		<a class="nav-link" aria-current="page" href="https://www.facebook.com"><i class="bi bi-facebook"></i></a>
		</li>
		<li class="nav-item">
	  		<a class="nav-link" id="drop" aria-current="page" href="https://www.instagram.com"><i class="bi bi-instagram"></i></a>
		</li>
		<li class="nav-item">
	  		<a class="nav-link" id="drop" aria-current="page" href="https://www.youtube.com"><i class="bi bi-youtube"></i></a>
		</li>
		<li class="nav-item">
	  		<a class="nav-link" id="drop" aria-current="page" href="https://www.tiktok.com"><i class="bi bi-tiktok"></i></a>
		</li>
		<li class="nav-item">
	  		<a class="nav-link" id="drop" aria-current="page" href="<?php echo get_template_directory_uri();?>/cart.php?action=all"><i class="bi bi-cart"></i></a>
		</li>
	</ul>
</div>