<div class="w-100">
	<div class="container-fluid pt-2 col-md-5 float-start">
	    <h6 class="navbar-brand text-dark float-start pt-2" href="#">Categories</h6>
	    <button class="navbar-toggler float-end" type="button" data-bs-toggle="collapse" data-bs-target="#categories" aria-controls="categories" aria-expanded="false" aria-label="Toggle navigation">
	    	<span class="navbar-toggler-icon"></span>
	    </button>
	    <div class="collapse navbar-collapse" id="categories">
	    	
	    	<div id="cats">
				<ul class="w-100">
				    <li class="nav-item d-inline-block"><a class="nav-link text-light fs-5" href="#">Apple</a></li>
				    <li class="nav-item d-inline-block"><a class="nav-link text-light fs-5" href="#">Samsung</a></li>
				    <li class="nav-item d-inline-block"><a class="nav-link text-light fs-5" href="#">Sony</a></li>
				</ul>
			</div>

	    </div>
	</div>
	<div class="col-md-4 col-sm-5 col-xl-4">
		<?php if ( is_active_sidebar( 'sidebar-search' ) ): ?>

			<?php dynamic_sidebar( 'sidebar-search' ); ?>

		<?php endif; ?>
	</div>
</div>