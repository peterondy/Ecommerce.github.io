<section id="slide">
	<div class="container" style="height: 80vh;">
		<div style="width: 100%;height: 100%;" id="carouselExampleDark" class="carousel carousel-dark slide" data-bs-ride="carousel">
		  <div class="carousel-indicators">
		    <button type="button" data-bs-target="#carouselExampleDark" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
		    <button type="button" data-bs-target="#carouselExampleDark" data-bs-slide-to="1" aria-label="Slide 2"></button>
		    <button type="button" data-bs-target="#carouselExampleDark" data-bs-slide-to="2" aria-label="Slide 3"></button>
		  </div>
		  <div class="carousel-inner" style="width: 100%; height: 100%;">
		    <div class="carousel-item active" data-bs-interval="3000" style="width: 100%; height: 100%;">
		      <img src="<?php echo get_template_directory_uri();?>/assets/img/slide1.jpg" style="width: 100%;height: 100%;" class="d-block w-100" alt="...">
		      <div class="carousel-caption d-none d-md-block">
		        <h5 class="text-light">Laptop's</h5>
		        <p class="text-info">We have laptop s .</p>
		      </div>
		    </div>
		    <div class="carousel-item" data-bs-interval="3000" style="width: 100%; height: 100%;">
		      <img src="<?php echo get_template_directory_uri();?>/assets/img/slide2.jpg" style="width: 100%;height: 100%;" class="d-block w-100" alt="...">
		      <div class="carousel-caption d-none d-md-block">
		        <h5 class="text-secondary">phone & Watches</h5>
		        <p>We have phone & Watches .</p>
		      </div>
		    </div>
		    <div class="carousel-item" style="width: 100%; height: 100%;">
		      <img src="<?php echo get_template_directory_uri();?>/assets/img/slide3.jpg" style="width: 100%;height: 100%;" class="d-block w-100" alt="...">
		      <div class="carousel-caption d-none d-md-block">
		        <h5 class="text-success">Clothes</h5>
		        <p>We have Clothes .</p>
		      </div>
		    </div>
		  </div>
		  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleDark" data-bs-slide="prev">
		    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
		    <span class="visually-hidden">Previous</span>
		  </button>
		  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleDark" data-bs-slide="next">
		    <span class="carousel-control-next-icon" aria-hidden="true"></span>
		    <span class="visually-hidden">Next</span>
		  </button>
		</div>
	</div>
</section>
