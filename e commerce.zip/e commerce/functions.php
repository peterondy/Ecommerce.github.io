<?php
	add_theme_support("post-thumbnails");
	add_theme_support("widgets");
	add_theme_support("menus");

	// ============== register sidebars =======================

	register_sidebar( array(
	    'name'          => __( 'Pages Sidebar', 'pages' ),
	    'id'            => 'sidebar-pages',
	    'before_widget' => '<div class="collapse navbar-collapse" id="navbarSupportedContent">',
	    'after_widget'  => '</div>',
	    'before_title'  => '',
	    'after_title'   => '',
	) );

	register_sidebar( array(
	    'name'          => __( 'Social Media Sidebar', 'socialMedia' ),
	    'id'            => 'sidebar-social-media',
	    'before_widget' => '',
	    'after_widget'  => '',
	    'before_title'  => '',
	    'after_title'   => '',
	) );

	register_sidebar( array(
	    'name'          => __( 'Categories Sidebar', 'categories' ),
	    'id'            => 'sidebar-categories',
	    'before_widget' => '',
	    'after_widget'  => '',
	    'before_title'  => '',
	    'after_title'   => '',
	) );

	register_sidebar( array(
	    'name'          => __( 'Search Sidebar', 'search' ),
	    'id'            => 'sidebar-search',
	    'before_widget' => '',
	    'after_widget'  => '',
	    'before_title'  => '',
	    'after_title'   => '',
	) );

	register_sidebar( array(
	    'name'          => __( 'Recents Posts', 'recent' ),
	    'id'            => 'recent-posts',
	    'before_widget' => '',
	    'after_widget'  => '',
	    'before_title'  => '',
	    'after_title'   => '',
	) );


//add new post type named items
	function itemsCustomPost(){

		$args = array(
			'labels' => array(
				'name' => 'Items',
				'singular_name' => 'Car'
			),
			'hierarchical' => false,
			'menu_icon' => 'dashicons-products',
			'public' => true,
			'has_archive' => true,
			'supports' => array('title', 'editor', 'thumbnail', 'custom-fields')
		);

		register_post_type('items', $args);

	}
	add_action('init', 'itemsCustomPost');

	//add categories section named categories for items custom type

	function categoriesItems(){

		$args = array(
			'labels' => array(
				'name' => 'Categories',
				'singular_name' => 'Categorie'
			),
			'hierarchical' => false,
			'public' => true
		);

		register_taxonomy('Categories', array("items"), $args);

	}
	add_action('init', 'categoriesItems');

	//add brands section named brands for items custom type

	function brandsItems(){

		$args = array(
			'labels' => array(
				'name' => 'Brands',
				'singular_name' => 'brand'
			),
			'hierarchical' => false,
			'public' => true,
		);

		register_taxonomy('Brands', array("items"), $args);

	}
	add_action('init', 'brandsItems');

	//show posts of post type in home page

	add_action( 'pre_get_posts', 'add_my_post_types_to_query' );

	function add_my_post_types_to_query( $query ) {
	  if ( is_home() && $query->is_main_query() )
	    $query->set( 'post_type', 'items' );
	  return $query;
	}

