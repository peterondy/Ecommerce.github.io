	<?php get_template_part( 'si-post' ); ?>
	<main>
		<div class="container mt-3">

				<h1 class="text-center"><?php the_title();?></h1>
				<?php if ( have_posts() ):?>
					<div id="single-post-card">
					    <?php the_post_thumbnail(); ?>
					    <div class="card-body">
					      	<h1><?php the_title(); ?></h1>
			    			<p><?php the_excerpt(); ?></p>
					    </div>
					    <div class="card-footer">
					      <a href="<?php echo get_template_directory_uri();?>/cart.php?action=add&id=<?php echo get_the_ID();?>" class="btn m-auto text-light text-center" style="background-color: #ff8e04;">Add To Cart</a>
					      <?php if(get_post_meta($post->ID, 'color', true)): ?>
					      	<span class="btn btn-danger text-center">color : <?php echo get_post_meta($post->ID, 'color', true); ?></span>
					  	  <?php endif; ?>
					  	  <?php if(get_post_meta($post->ID, 'price', true)): ?>
					      	<span class="btn btn-success text-center">price : <?php echo get_post_meta($post->ID, 'price', true); ?></span>
					  	  <?php endif; ?>
					  	  <?php $taxs = get_queried_object();?>
					      	<span class="btn btn-primary text-center">tags : <?php echo $taxs->name;?></span>
					    </div>
					</div>
				<?php endif; ?>

		</div>
	</main>

<?php get_footer();?>