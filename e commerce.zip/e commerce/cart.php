<?php include "card-header.php";
require_once('../../../wp-load.php');
$mydb = new wpdb('root','','wordpress','localhost');?>
<main id="main-cart">
		<div class="container pt-5" style="height: 1500px;background-color: #e3e3e3;">
			<?php if(isset($_GET['action'])): ?>
				<?php if($_GET['action'] == ""): ?>
					<h1 class="alert alert-danger">Page Not Found</h1>
			    <?php elseif($_GET['action'] == "add" && isset($_GET['id']) && $_GET['action'] != ""): ?>
					<?php 
						// add item to wordpress database
						$ID = $_GET['id'];
						$iFItemExist = $wpdb->get_row( "SELECT postID FROM cart WHERE postID = $ID" );
						$changeToArray = json_decode(json_encode($iFItemExist), true);
						

						if ( $ID == $changeToArray['postID'] ):?>
							<h1 class="alert alert-danger">The Item Are Exist In The Cart Only</h1>
							<a href="http://localhost/wordpress/index.php" class="btn btn-success">GO Back To Home Page</a>
							<a href="cart.php?action=all" class="btn btn-primary">cart items</a>
						<?php elseif($changeToArray['postID'] == array()) :?>
							<?php $date = date('Y-m-d');
				            $wpdb->insert( 'cart', array( 'postID' => $_GET['id'], 'date' => $date ) );?>
							<h1 class="alert alert-success">The Item Are Added To Cart</h1>
							<a href="localhost://localhost/wordpress/index.php" class="btn btn-success">GO Back To Home Page</a>
							<a href="cart.php?action=all" class="btn btn-primary">cart items</a>
						<?php else: ?>
							<h1 class="alert alert-danger">Page Not Found</h1>
							<a href="localhost://localhost/wordpress/index.php" class="btn btn-success">GO Back To Home Page</a>
							<a href="cart.php?action=all" class="btn btn-primary">cart items</a>
						<?php endif;?>
				<?php elseif($_GET['action'] == "all"): 

					//get all elements exist in cart?>
					<h1>Cart Items</h1>
					<?php $selectAllCartElement = $wpdb->get_results( "SELECT * FROM " . 'cart');
					
					$changeCartToArray = json_decode(json_encode($selectAllCartElement), true);?>

						<?php foreach($changeCartToArray as $result):?>

								<?php
									$ID = $result['postID'];
									
									$getPosts = $wpdb->get_row( "SELECT post_title, post_content, post_date FROM $wpdb->posts WHERE ID = $ID AND post_type = 'items' AND post_status = 'publish'" );
									$changeToArray = json_decode(json_encode($getPosts), true);
								?>
					

							<div class="card float-start">
							  <!--<img src="..." class="card-img-top" alt="...">-->
							  <?php //echo $changeToArray['meta_key']; ?>
							  <div class="card-body">
							    <h1><?php echo $changeToArray['post_title']; ?></h1>
							    <p><?php echo $changeToArray['post_content']; ?></p>
							  </div>
							    <div class="card-footer">
							      <a href="<?php echo get_template_directory_uri();?>/cart.php?action=remove&id=<?php echo $ID;?>" class="btn btn-danger text-light">Romeve From To Cart</a>
							      <span class="btn btn-success text-light">200$</span>
							      <span class="btn btn-primary text-light"><?php echo $changeToArray['post_date']; ?></span>
							    </div>
							</div>
						<?php endforeach;?>

				<?php elseif($_GET['action'] == "remove"):?>
					
				    <?php $delete = $wpdb->query( 'DELETE FROM `cart` WHERE `postID` = $_GET["id"]' );echo $delete;?>
					
					<h1 class="alert alert-danger">The Item Are Deleted</h1>
					<a href="localhost://localhost/wordpress/index.php" class="btn btn-success">GO Back To Home Page</a>
					<a href="cart.php?action=all" class="btn btn-primary">cart items</a>
				<?php else:?>
					<h1 class="alert alert-danger">Page Not Found</h1>
				<?php endif;?>
			<?php else:?>
				<h1 class="alert alert-danger">Page Not Found</h1>
			<?php endif;?>
		<div>
			
	    </div>
		</div>
	</main>
<?php get_footer();?>