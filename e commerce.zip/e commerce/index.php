<?php require "header.php";?>

<?php //wp_redirect( 'cart.php' ); exit; ?>


	<main>
		<div class="container mt-3">

				<h1>All Items</h1>
				<?php if ( have_posts() ) : while( have_posts()  ) : the_post(); ?>
					<div id="card-post" class="card float-start">
					    <?php the_post_thumbnail();  ?>
					    <?php //the name of the thumbnail
					    //echo get_post(get_post_thumbnail_id())->post_title; ?>
					    <div class="card-body">
					      	<h1><?php the_title(); ?></h1>
			    			<p><?php the_excerpt(); ?></p>
					    </div>
					    <div class="card-footer">
					      <a href="<?php the_permalink(); ?>" class="btn btn-primary text-light">Read More</a>
					      <a href="<?php echo get_template_directory_uri();?>/cart.php?action=add&id=<?php echo get_the_ID();?>" class="btn m-auto text-light" style="background-color: #ff8e04;">Add To Cart</a>
					  	  <?php if(get_post_meta($post->ID, 'price', true)): ?>
					      	<span class="btn btn-success">price : <?php echo get_post_meta($post->ID, 'price', true); ?></span>
					  	  <?php endif; ?>
					    </div>
					</div>
				<?php endwhile; endif; ?>

		</div>
		<div id="side">
			<?php if ( is_active_sidebar( 'recent-posts' ) ): ?>

			    <?php dynamic_sidebar( 'recent-posts' ); ?>
			    
			<?php endif; ?>
		</div>
	</main>

<?php get_sidebar();?>
<?php get_footer();?>